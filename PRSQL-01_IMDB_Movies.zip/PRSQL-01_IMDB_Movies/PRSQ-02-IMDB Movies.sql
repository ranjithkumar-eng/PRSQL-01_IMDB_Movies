SHOW DATABASES;

USE project_movie_database;

SHOW TABLES;

DESCRIBE movies;

DESCRIBE directors;

-- Q a)	Can you get all data about movies? 
SELECT * FROM movies;

-- Q b)	How do you get all data about directors?
SELECT * FROM directors;

-- Q c)	Check how many movies are present in IMDB.
SELECT COUNT(*) AS total_movies
FROM movies;

-- Q d)	Find these 3 directors: James Cameron ; Luc Besson ; John Woo
SELECT *
FROM directors
WHERE name IN (
    'James Cameron',
    'Luc Besson',
    'John Woo'
);

-- Q e)	Find all directors with name starting with S.
SELECT *
FROM directors
WHERE name LIKE 'S%';

-- Q f)	Count female directors.
SELECT COUNT(*) AS female_directors
FROM directors
WHERE gender = 1;

-- Q g)	Find the name of the 10th first women directors?
SELECT name
FROM directors
WHERE gender = 1
ORDER BY name
LIMIT 1 OFFSET 9;

-- Q h)	What are the 3 most popular movies?
SELECT original_title, popularity
FROM movies
ORDER BY popularity DESC
LIMIT 3;

-- Q i)	What are the 3 most bankable movies?
SELECT original_title, revenue
FROM movies
ORDER BY revenue DESC
LIMIT 3;

-- Q j)	What is the most awarded average vote since the January 1st, 2000?
SELECT original_title, vote_average, release_date
FROM movies
WHERE release_date >= '2000-01-01'
ORDER BY vote_average DESC
LIMIT 1;

-- Q k)	Which movie(s) were directed by Brenda Chapman?
SELECT *
FROM directors
WHERE name LIKE '%Brenda Chapman%';

-- Q l)	Which director made the most movies?
SELECT d.name, COUNT(*) AS total_movies
FROM movies m
JOIN directors d
ON m.director_id = d.id
GROUP BY d.id, d.name
ORDER BY total_movies DESC
LIMIT 1;

-- Q m)	Which director is the most bankable?
SELECT d.name, SUM(m.revenue) AS total_revenue
FROM movies m
JOIN directors d
ON m.director_id = d.id
GROUP BY d.id, d.name
ORDER BY total_revenue DESC
LIMIT 1;

SHOW DATABASES;

USE project_movie_database;

SHOW TABLES;

DESCRIBE movies;

DESCRIBE directors;

